package com.eshop.app.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.eshop.app.entity.Product;

@Repository
public class ProductRepository {
	
	@Autowired
	private SessionFactory factory;
	
	public void saveProduct(Product product) {
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			
			session.save(product);
			
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	public List<Product> getAllProduct() {
		Session session = null;
		List<Product> list = null;
		try {
			session = factory.openSession();
			Criteria criteria = session.createCriteria(Product.class);
			list = criteria.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
