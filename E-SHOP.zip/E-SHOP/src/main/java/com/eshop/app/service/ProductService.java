package com.eshop.app.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.eshop.app.entity.Product;
import com.eshop.app.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository repository;
	
	@Value("${file.upload-dir}")
	private String uploadDir;
	
	private static final String BASE_URL = "http://localhost:8080/images/";

	public void saveProduct(String productTitle, double originalPrice, double discountPercentage, String description,
			int productQuantity, String productCategory, MultipartFile image) throws IOException {
		
		// Create uploads folder if not Exist
		File uploadFolder = new File(uploadDir);
		
		if(!uploadFolder.exists()) {
			uploadFolder.mkdir();
		}
		
		// MultipartFile -> image data, image name, image type
		byte[] imageData = image.getBytes();
		String imageName = image.getOriginalFilename();
		String imageType = image.getContentType();
		
		// Check the image type is valid or not
		if(imageType == null || !imageType.startsWith("image/")) {
			throw new IllegalArgumentException("Invalid Image type");
		}
		
		// Create FilePath ( uploads, file-serve )
		// Generate random ID for image
		String newImageName = UUID.randomUUID() + "_" + imageName;
		
		Path uploadImagePath = Paths.get(uploadDir, newImageName);
		
		String imageServePath = BASE_URL + newImageName;
		
		// Save file in uploads folder
		Files.write(uploadImagePath, imageData);
		
		// Calculate selling price
		double discount = originalPrice * discountPercentage / 100.0;
		double sellingPrice = originalPrice - discount;
		
		int ratings = 1;
		
		// Create product entity object
		Product product = new Product(productTitle, originalPrice, sellingPrice, discountPercentage,
				description, productQuantity, productCategory, imageServePath,
				imageName, imageType, ratings);
		
		// Calling repository saveProduct method to save product into database
		repository.saveProduct(product);
	}

	public List<Product> getAllProduct() {
		List<Product> list = null;
		try {
			list = repository.getAllProduct();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
}
